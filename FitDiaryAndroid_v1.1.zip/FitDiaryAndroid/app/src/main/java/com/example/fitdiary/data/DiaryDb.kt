package com.example.fitdiary.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DiaryDb(context: Context) : SQLiteOpenHelper(context, "fit_diary.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE workouts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, createdAt INTEGER NOT NULL, note TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE exercises(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, muscle TEXT NOT NULL, instructions TEXT NOT NULL, photoUri TEXT DEFAULT NULL, isCustom INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE workout_exercises(id INTEGER PRIMARY KEY AUTOINCREMENT, workoutId INTEGER NOT NULL, exerciseId INTEGER NOT NULL, sortOrder INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE TABLE sets(id INTEGER PRIMARY KEY AUTOINCREMENT, workoutExerciseId INTEGER NOT NULL, setNo INTEGER NOT NULL, weight REAL NOT NULL, reps INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE pressure(id INTEGER PRIMARY KEY AUTOINCREMENT, measuredAt INTEGER NOT NULL, systolic INTEGER NOT NULL, diastolic INTEGER NOT NULL, pulse INTEGER, note TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE sleep(id INTEGER PRIMARY KEY AUTOINCREMENT, sleepDate INTEGER NOT NULL, bedtime TEXT NOT NULL, wakeTime TEXT NOT NULL, durationMin INTEGER NOT NULL, quality INTEGER NOT NULL, note TEXT DEFAULT '')")
        db.execSQL("CREATE TABLE measurements(id INTEGER PRIMARY KEY AUTOINCREMENT, measuredAt INTEGER NOT NULL, weight REAL, waist REAL, chest REAL, shoulders REAL, arm REAL, thigh REAL)")
        seedExercises(db)
    }

    private fun seedExercises(db: SQLiteDatabase) {
        val rows = listOf(
            Triple("Жим штанги лёжа", "Грудь", "Ляг на скамью, сведи лопатки, опускай штангу контролируемо к нижней части груди. Не отбивай от груди."),
            Triple("Жим в тренажёре", "Грудь", "Настрой сиденье так, чтобы рукояти были примерно на уровне середины груди. Выжимай плавно, не блокируй локти."),
            Triple("Жим гантелей на наклонной скамье", "Грудь", "Угол скамьи около 20–30°. Опускай гантели по бокам груди, сохраняй контроль и устойчивость плеч."),
            Triple("Сведение рук в тренажёре", "Грудь", "Слегка согни локти, своди рукояти перед грудью без рывков. Не растягивай плечи чрезмерно."),
            Triple("Тяга верхнего блока", "Спина", "Сядь устойчиво, опускай рукоять к верхней части груди, направляя локти вниз. Не раскачивай корпус."),
            Triple("Горизонтальная тяга блока", "Спина", "Сохраняй нейтральную спину, тяни рукоять к поясу, своди лопатки без рывка корпусом."),
            Triple("Тяга с упором грудью", "Спина", "Прижми грудь к опоре, тяни рукояти к корпусу, контролируй возвращение веса."),
            Triple("Обратная бабочка", "Плечи", "Настрой рукояти на уровне плеч. Разводи руки в стороны, не поднимай плечи к ушам."),
            Triple("Разведение гантелей в стороны", "Плечи", "Небольшой сгиб локтей, поднимай гантели до уровня плеч. Используй лёгкий вес и не раскачивайся."),
            Triple("Жим гантелей сидя", "Плечи", "Сиди с опорой спины, выжимай гантели вверх в комфортной амплитуде. Не прогибай поясницу."),
            Triple("Сгибание рук с гантелями", "Бицепс", "Локти держи около корпуса, сгибай руки без раскачивания. Опускай гантели медленно."),
            Triple("Молотковые сгибания", "Бицепс", "Держи гантели нейтральным хватом, сгибай локти, не помогай корпусом."),
            Triple("Разгибание рук на блоке", "Трицепс", "Прижми локти к корпусу и разгибай руки вниз. Не разводи локти в стороны."),
            Triple("Сгибание ног в тренажёре", "Ноги", "Двигай валик плавно, не делай рывков. Выбирай амплитуду без боли в колене."),
            Triple("Ягодичный мост", "Ноги", "Поднимай таз за счёт ягодиц, удерживая рёбра опущенными. Не переразгибай поясницу."),
            Triple("Подъём на носки", "Ноги", "Поднимайся на носки плавно, задерживайся наверху и медленно опускай пятки."),
            Triple("Планка", "Пресс", "Удерживай корпус прямым, напряги ягодицы и живот, не проваливай поясницу."),
            Triple("Pallof press", "Пресс", "Встань боком к блоку, удерживай корпус неподвижно и выжимай рукоять перед собой."),
            Triple("Скручивания на блоке", "Пресс", "Скручивай грудную клетку к тазу, не тяни вес руками и не дёргай шею."),
            Triple("Ходьба на дорожке", "Кардио", "Начни с комфортного темпа и постепенно увеличивай продолжительность. Остановись при необычных симптомах.")
        )
        rows.forEach { (name, muscle, instructions) ->
            val cv = ContentValues().apply { put("name", name); put("muscle", muscle); put("instructions", instructions); put("isCustom", 0) }
            db.insert("exercises", null, cv)
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    data class Workout(val id: Long, val name: String, val createdAt: Long, val note: String)
    data class Exercise(val id: Long, val name: String, val muscle: String, val instructions: String, val photoUri: String?, val isCustom: Boolean)
    data class WorkoutExercise(val id: Long, val workoutId: Long, val exerciseId: Long, val name: String, val muscle: String)
    data class SetRow(val id: Long, val workoutExerciseId: Long, val setNo: Int, val weight: Double, val reps: Int)
    data class Pressure(val id: Long, val measuredAt: Long, val systolic: Int, val diastolic: Int, val pulse: Int?, val note: String)
    data class Sleep(val id: Long, val sleepDate: Long, val bedtime: String, val wakeTime: String, val durationMin: Int, val quality: Int, val note: String)
    data class Measurement(val id: Long, val measuredAt: Long, val weight: Double?, val waist: Double?, val chest: Double?, val shoulders: Double?, val arm: Double?, val thigh: Double?)

    fun workouts(): List<Workout> = readableDatabase.rawQuery("SELECT id,name,createdAt,note FROM workouts ORDER BY createdAt DESC", null).use { c -> buildList { while(c.moveToNext()) add(Workout(c.getLong(0),c.getString(1),c.getLong(2),c.getString(3))) } }
    fun addWorkout(name: String, note: String = ""): Long = writableDatabase.insert("workouts", null, ContentValues().apply { put("name",name); put("createdAt",System.currentTimeMillis()); put("note",note) })
    fun exercises(muscle: String? = null): List<Exercise> {
        val sql = if (muscle == null || muscle == "Все") "SELECT id,name,muscle,instructions,photoUri,isCustom FROM exercises ORDER BY muscle,name" else "SELECT id,name,muscle,instructions,photoUri,isCustom FROM exercises WHERE muscle=? ORDER BY name"
        return readableDatabase.rawQuery(sql, if (muscle == null || muscle == "Все") null else arrayOf(muscle)).use { c -> buildList { while(c.moveToNext()) add(Exercise(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),if(c.isNull(4)) null else c.getString(4),c.getInt(5)==1)) } }
    }
    fun addExercise(name: String, muscle: String, instructions: String, photoUri: String?): Long = writableDatabase.insert("exercises", null, ContentValues().apply { put("name",name); put("muscle",muscle); put("instructions",instructions); put("photoUri",photoUri); put("isCustom",1) })
    fun setExercisePhoto(id: Long, uri: String) { writableDatabase.update("exercises", ContentValues().apply { put("photoUri",uri) }, "id=?", arrayOf(id.toString())) }
    fun addExerciseToWorkout(workoutId: Long, exerciseId: Long) { writableDatabase.insert("workout_exercises", null, ContentValues().apply { put("workoutId",workoutId); put("exerciseId",exerciseId); put("sortOrder",System.currentTimeMillis()) }) }
    fun workoutExercises(workoutId: Long): List<WorkoutExercise> = readableDatabase.rawQuery("SELECT we.id,we.workoutId,we.exerciseId,e.name,e.muscle FROM workout_exercises we JOIN exercises e ON e.id=we.exerciseId WHERE we.workoutId=? ORDER BY we.sortOrder", arrayOf(workoutId.toString())).use { c -> buildList { while(c.moveToNext()) add(WorkoutExercise(c.getLong(0),c.getLong(1),c.getLong(2),c.getString(3),c.getString(4))) } }
    fun addSet(workoutExerciseId: Long, setNo: Int, weight: Double, reps: Int) { writableDatabase.insert("sets", null, ContentValues().apply { put("workoutExerciseId",workoutExerciseId); put("setNo",setNo); put("weight",weight); put("reps",reps) }) }
    fun sets(workoutExerciseId: Long): List<SetRow> = readableDatabase.rawQuery("SELECT id,workoutExerciseId,setNo,weight,reps FROM sets WHERE workoutExerciseId=? ORDER BY id", arrayOf(workoutExerciseId.toString())).use { c -> buildList { while(c.moveToNext()) add(SetRow(c.getLong(0),c.getLong(1),c.getInt(2),c.getDouble(3),c.getInt(4))) } }
    fun addPressure(s: Int,d: Int,p: Int?,note: String) { writableDatabase.insert("pressure",null,ContentValues().apply { put("measuredAt",System.currentTimeMillis()); put("systolic",s); put("diastolic",d); if(p==null) putNull("pulse") else put("pulse",p); put("note",note) }) }
    fun pressures(): List<Pressure> = readableDatabase.rawQuery("SELECT id,measuredAt,systolic,diastolic,pulse,note FROM pressure ORDER BY measuredAt DESC",null).use { c -> buildList { while(c.moveToNext()) add(Pressure(c.getLong(0),c.getLong(1),c.getInt(2),c.getInt(3),if(c.isNull(4)) null else c.getInt(4),c.getString(5))) } }
    fun addSleep(date: Long, bed: String, wake: String, duration: Int, quality: Int, note: String) { writableDatabase.insert("sleep",null,ContentValues().apply { put("sleepDate",date); put("bedtime",bed); put("wakeTime",wake); put("durationMin",duration); put("quality",quality); put("note",note) }) }
    fun sleeps(): List<Sleep> = readableDatabase.rawQuery("SELECT id,sleepDate,bedtime,wakeTime,durationMin,quality,note FROM sleep ORDER BY sleepDate DESC",null).use { c -> buildList { while(c.moveToNext()) add(Sleep(c.getLong(0),c.getLong(1),c.getString(2),c.getString(3),c.getInt(4),c.getInt(5),c.getString(6))) } }
    fun addMeasurement(weight: Double?,waist: Double?,chest: Double?,shoulders: Double?,arm: Double?,thigh: Double?) { writableDatabase.insert("measurements",null,ContentValues().apply { put("measuredAt",System.currentTimeMillis()); putNullable("weight",weight); putNullable("waist",waist); putNullable("chest",chest); putNullable("shoulders",shoulders); putNullable("arm",arm); putNullable("thigh",thigh) }) }
    private fun ContentValues.putNullable(key: String, value: Double?) { if(value==null) putNull(key) else put(key,value) }
    fun measurements(): List<Measurement> = readableDatabase.rawQuery("SELECT id,measuredAt,weight,waist,chest,shoulders,arm,thigh FROM measurements ORDER BY measuredAt DESC",null).use { c -> buildList { while(c.moveToNext()) add(Measurement(c.getLong(0),c.getLong(1),nullableDouble(c,2),nullableDouble(c,3),nullableDouble(c,4),nullableDouble(c,5),nullableDouble(c,6),nullableDouble(c,7))) } }
    private fun nullableDouble(c: android.database.Cursor, i: Int): Double? = if(c.isNull(i)) null else c.getDouble(i)

    fun deleteWorkout(id: Long) { writableDatabase.apply { beginTransaction(); try {
        execSQL("DELETE FROM sets WHERE workoutExerciseId IN (SELECT id FROM workout_exercises WHERE workoutId=?)", arrayOf<Any>(id))
        execSQL("DELETE FROM workout_exercises WHERE workoutId=?", arrayOf<Any>(id))
        execSQL("DELETE FROM workouts WHERE id=?", arrayOf<Any>(id))
        setTransactionSuccessful() } finally { endTransaction() } } }
    fun deleteWorkoutExercise(id: Long) { writableDatabase.apply { beginTransaction(); try {
        execSQL("DELETE FROM sets WHERE workoutExerciseId=?", arrayOf<Any>(id))
        execSQL("DELETE FROM workout_exercises WHERE id=?", arrayOf<Any>(id))
        setTransactionSuccessful() } finally { endTransaction() } } }
    fun deleteSet(id: Long) { writableDatabase.delete("sets", "id=?", arrayOf(id.toString())) }
    fun deletePressure(id: Long) { writableDatabase.delete("pressure", "id=?", arrayOf(id.toString())) }
    fun deleteSleep(id: Long) { writableDatabase.delete("sleep", "id=?", arrayOf(id.toString())) }
    fun deleteMeasurement(id: Long) { writableDatabase.delete("measurements", "id=?", arrayOf(id.toString())) }

    /** CSV с разделителем «;» и BOM — корректно открывается в Excel с русской локалью. */
    fun exportCsv(): String {
        val df = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        fun q(s: String?) = "\"" + (s ?: "").replace("\"", "\"\"") + "\""
        fun n(v: Double?) = v?.let { String.format(Locale.US, "%.1f", it).replace('.', ',') } ?: ""
        val sb = StringBuilder("\uFEFF")
        sb.append("ТРЕНИРОВКИ\r\nДата;Тренировка;Упражнение;Группа;Подход;Вес кг;Повторы\r\n")
        readableDatabase.rawQuery("SELECT w.createdAt,w.name,e.name,e.muscle,s.weight,s.reps FROM sets s JOIN workout_exercises we ON we.id=s.workoutExerciseId JOIN workouts w ON w.id=we.workoutId JOIN exercises e ON e.id=we.exerciseId ORDER BY w.createdAt,we.sortOrder,s.id", null).use { c ->
            var no = 0; var last = -1L
            while (c.moveToNext()) { val key = c.getLong(0) * 31 + c.getString(2).hashCode(); no = if (key == last) no + 1 else 1; last = key
                sb.append(df.format(Date(c.getLong(0)))).append(';').append(q(c.getString(1))).append(';').append(q(c.getString(2))).append(';').append(q(c.getString(3))).append(';').append(no).append(';').append(n(c.getDouble(4))).append(';').append(c.getInt(5)).append("\r\n") }
        }
        sb.append("\r\nДАВЛЕНИЕ\r\nДата;Верхнее;Нижнее;Пульс;Комментарий\r\n")
        pressures().reversed().forEach { sb.append(df.format(Date(it.measuredAt))).append(';').append(it.systolic).append(';').append(it.diastolic).append(';').append(it.pulse ?: "").append(';').append(q(it.note)).append("\r\n") }
        sb.append("\r\nСОН\r\nДата;Лёг;Проснулся;Минут;Качество 1-5;Комментарий\r\n")
        sleeps().reversed().forEach { sb.append(df.format(Date(it.sleepDate))).append(';').append(it.bedtime).append(';').append(it.wakeTime).append(';').append(it.durationMin).append(';').append(it.quality).append(';').append(q(it.note)).append("\r\n") }
        sb.append("\r\nЗАМЕРЫ\r\nДата;Вес кг;Талия см;Грудь см;Плечи см;Рука см;Бедро см\r\n")
        measurements().reversed().forEach { sb.append(df.format(Date(it.measuredAt))).append(';').append(n(it.weight)).append(';').append(n(it.waist)).append(';').append(n(it.chest)).append(';').append(n(it.shoulders)).append(';').append(n(it.arm)).append(';').append(n(it.thigh)).append("\r\n") }
        return sb.toString()
    }
}
