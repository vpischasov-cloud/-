package com.example.fitdiary

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.MonitorWeight
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.fitdiary.data.DiaryDb
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = DiaryDb(this)
        setContent { FitDiaryApp(db) }
    }
}

private enum class Tab(val title: String) { HOME("Главная"), TRAINING("Зал"), HEALTH("Здоровье"), BODY("Замеры"), ANALYTICS("Аналитика") }
private val ink = Color(0xFF10151C)
private val panel = Color(0xFF1B2430)
private val mint = Color(0xFF7BE0A0)
private val muted = Color(0xFF9BA8B8)

@Composable
private fun FitDiaryApp(db: DiaryDb) {
    var tabIdx by rememberSaveable { mutableStateOf(0) }
    val tab = Tab.entries[tabIdx]
    var refresh by remember { mutableIntStateOf(0) }
    var selectedId by rememberSaveable { mutableStateOf(-1L) }
    val selectedWorkout = remember(refresh, selectedId) { db.workouts().firstOrNull { it.id == selectedId } }
    MaterialTheme(colorScheme = darkColorScheme(primary = mint, background = ink, surface = panel, onPrimary = ink, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(
            containerColor = ink,
            topBar = { TopAppBarFit(tab.title) },
            bottomBar = {
                NavigationBar(containerColor = panel, contentColor = Color.White) {
                    listOf(Tab.HOME, Tab.TRAINING, Tab.HEALTH, Tab.BODY, Tab.ANALYTICS).forEach { item ->
                        val icon = when(item) { Tab.HOME -> Icons.Default.FitnessCenter; Tab.TRAINING -> Icons.Default.Tune; Tab.HEALTH -> Icons.Default.Favorite; Tab.BODY -> Icons.Default.MonitorWeight; Tab.ANALYTICS -> Icons.Default.BarChart }
                        NavigationBarItem(selected = tab == item, onClick = { tabIdx = item.ordinal }, icon = { Icon(icon, null) }, label = { Text(item.title, fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = mint, selectedTextColor = mint, indicatorColor = Color(0xFF30463C), unselectedIconColor = muted, unselectedTextColor = muted))
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when(tab) {
                    Tab.HOME -> HomeScreen(db, refresh, onGo = { tabIdx = it.ordinal })
                    Tab.TRAINING -> TrainingScreen(db, refresh, { refresh++ }, selectedWorkout, { selectedId = it?.id ?: -1L })
                    Tab.HEALTH -> HealthScreen(db, refresh, { refresh++ })
                    Tab.BODY -> BodyScreen(db, refresh, { refresh++ })
                    Tab.ANALYTICS -> AnalyticsScreen(db, refresh)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarFit(title: String) {
    TopAppBar(title = { Column { Text("FIT DIARY", fontSize = 11.sp, color = mint, fontWeight = FontWeight.Bold, letterSpacing = 2.sp); Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold) } }, colors = TopAppBarDefaults.topAppBarColors(containerColor = ink, titleContentColor = Color.White))
}

@Composable
private fun HomeScreen(db: DiaryDb, refresh: Int, onGo: (Tab) -> Unit) {
    val measurements = remember(refresh) { db.measurements() }
    val pressures = remember(refresh) { db.pressures() }
    val sleeps = remember(refresh) { db.sleeps() }
    val workouts = remember(refresh) { db.workouts() }
    val latest = measurements.firstOrNull()
    val context = LocalContext.current
    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        if (uri != null) {
            val ok = runCatching { context.contentResolver.openOutputStream(uri)?.use { it.write(db.exportCsv().toByteArray(Charsets.UTF_8)) } }.isSuccess
            Toast.makeText(context, if (ok) "Данные сохранены в файл" else "Не удалось сохранить файл", Toast.LENGTH_LONG).show()
        }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            CardBox {
                Text("ТВОЯ ТРАНСФОРМАЦИЯ", color = mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.Bottom) { Text("${latest?.weight?.let { fmt(it) } ?: "—"}", fontSize = 34.sp, fontWeight = FontWeight.Bold); Text(" кг", color = muted, modifier = Modifier.padding(bottom = 5.dp)) }
                Text("Цель: 95 кг  ·  Талия: ${latest?.waist?.let { fmt(it) } ?: "—"} см", color = muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(progress = { ((108.0 - (latest?.weight ?: 108.0)) / 13.0).toFloat().coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(7.dp), color = mint, trackColor = Color(0xFF35404D))
                Text("До цели — ${latest?.weight?.let { fmt((it - 95).coerceAtLeast(0.0)) } ?: "13"} кг", color = muted, fontSize = 12.sp)
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Тренировки", workouts.size.toString(), "всего", Modifier.weight(1f))
            StatCard("Давление", pressures.firstOrNull()?.let { "${it.systolic}/${it.diastolic}" } ?: "—", "последнее", Modifier.weight(1f))
            StatCard("Сон", sleeps.firstOrNull()?.let { "${it.durationMin / 60} ч ${it.durationMin % 60} м" } ?: "—", "последний", Modifier.weight(1f))
        } }
        item { SectionTitle("Быстрый доступ") }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickCard("Начать тренировку", Icons.Default.FitnessCenter, Modifier.weight(1f)) { onGo(Tab.TRAINING) }
            QuickCard("Записать давление", Icons.Default.Favorite, Modifier.weight(1f)) { onGo(Tab.HEALTH) }
        } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickCard("Добавить замеры", Icons.Default.MonitorWeight, Modifier.weight(1f)) { onGo(Tab.BODY) }
            QuickCard("Посмотреть графики", Icons.Default.ShowChart, Modifier.weight(1f)) { onGo(Tab.ANALYTICS) }
        } }
        item { OutlinedButton(onClick = { exporter.launch("fitdiary_export.csv") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Download, null); Spacer(Modifier.width(8.dp)); Text("Экспорт данных в CSV") } }
        item { Text("Данные хранятся только на этом устройстве. Делай резервные копии: экспортируй CSV.", color = muted, fontSize = 12.sp) }
    }
}

@Composable
private fun TrainingScreen(db: DiaryDb, refresh: Int, onRefresh: () -> Unit, selectedWorkout: DiaryDb.Workout?, onSelect: (DiaryDb.Workout?) -> Unit) {
    val context = LocalContext.current
    var confirm by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    BackHandler(enabled = selectedWorkout != null) { onSelect(null) }
    var showNewWorkout by remember { mutableStateOf(false) }
    var showExercisePicker by remember { mutableStateOf(false) }
    var showCustomExercise by remember { mutableStateOf(false) }
    var activeExercise by remember { mutableStateOf<DiaryDb.WorkoutExercise?>(null) }
    var showSetDialog by remember { mutableStateOf(false) }
    var showExerciseInfo by remember { mutableStateOf<DiaryDb.Exercise?>(null) }
    val workouts = remember(refresh) { db.workouts() }
    val attached = remember(refresh, selectedWorkout?.id) { selectedWorkout?.let { db.workoutExercises(it.id) } ?: emptyList() }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        val ex = showExerciseInfo
        if (uri != null && ex != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            db.setExercisePhoto(ex.id, uri.toString()); showExerciseInfo = db.exercises().firstOrNull { it.id == ex.id }; onRefresh()
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        if (selectedWorkout == null) {
            Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Мои тренировки", fontSize = 21.sp, fontWeight = FontWeight.Bold); Text("Создавай свои планы и выбирай упражнения", color = muted, fontSize = 12.sp) }; FilledTonalButton(onClick = { showNewWorkout = true }) { Icon(Icons.Default.Add, null); Text("Создать") } }
            Spacer(Modifier.height(12.dp))
            if (workouts.isEmpty()) EmptyState("Пока нет тренировок", "Нажми «Создать», чтобы завести первую тренировку.")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(workouts) { w -> CardBox(Modifier.fillMaxWidth().clickable { onSelect(w) }) { Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(w.name, fontWeight = FontWeight.SemiBold, fontSize = 17.sp); Text(date(w.createdAt), color = muted, fontSize = 12.sp); if(w.note.isNotBlank()) Text(w.note, color = muted) }; IconButton(onClick = { confirm = Pair("Удалить тренировку «${w.name}» вместе с подходами?", { db.deleteWorkout(w.id) }) }) { Icon(Icons.Default.Delete, "Удалить тренировку", tint = muted) } } } }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { onSelect(null) }) { Text("← Все тренировки") }
                Spacer(Modifier.weight(1f))
                Text("${attached.size} упражн.", color = muted, fontSize = 12.sp)
            }
            Text(selectedWorkout.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Добавляй упражнения и записывай каждый подход", color = muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            FilledTonalButton(onClick = { showExercisePicker = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Text("Добавить упражнение") }
            Spacer(Modifier.height(8.dp))
            if (attached.isEmpty()) EmptyState("Тренировка пока пустая", "Добавь упражнения из каталога или создай своё.")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(attached) { item ->
                    val sets = remember(refresh, item.id) { db.sets(item.id) }
                    CardBox(Modifier.fillMaxWidth().clickable { activeExercise = item; showSetDialog = true }) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(item.name, fontWeight = FontWeight.SemiBold); Text(item.muscle, color = muted, fontSize = 12.sp) }; Text("+ Подход", color = mint, fontWeight = FontWeight.Bold); IconButton(onClick = { confirm = Pair("Убрать «${item.name}» из тренировки?", { db.deleteWorkoutExercise(item.id) }) }) { Icon(Icons.Default.Delete, "Убрать упражнение", tint = muted) } }
                        if (sets.isNotEmpty()) { Spacer(Modifier.height(6.dp)); sets.forEachIndexed { idx, st -> Row(verticalAlignment = Alignment.CenterVertically) { Text("${idx + 1}.  ${fmt(st.weight)} кг × ${st.reps}", color = muted, fontSize = 13.sp, modifier = Modifier.weight(1f)); IconButton(onClick = { db.deleteSet(st.id); onRefresh() }, modifier = Modifier.size(32.dp)) { Icon(Icons.Default.Delete, "Удалить подход", Modifier.size(16.dp), tint = muted) } } } } else Text("Нажми, чтобы записать подходы", color = muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
    if (showNewWorkout) InputDialog("Новая тренировка", listOf("Название"), listOf("Например: Грудь и плечи"), onDismiss = { showNewWorkout = false }) { v -> if(v[0].isNotBlank()) { db.addWorkout(v[0]); onRefresh() }; showNewWorkout = false }
    if (showExercisePicker) ExercisePicker(db, onDismiss = { showExercisePicker = false }, onCustom = { showExercisePicker = false; showCustomExercise = true }, onChoose = { ex -> selectedWorkout?.let { db.addExerciseToWorkout(it.id, ex.id) }; onRefresh(); showExercisePicker = false; showExerciseInfo = ex })
    if (showCustomExercise) CustomExerciseDialog(onDismiss = { showCustomExercise = false }) { name, muscle, instructions -> val id = db.addExercise(name, muscle, instructions, null); selectedWorkout?.let { db.addExerciseToWorkout(it.id, id) }; onRefresh(); showCustomExercise = false }
    if (showSetDialog && activeExercise != null) InputDialog("Записать подход", listOf("Вес, кг", "Повторения"), listOf("Например: 40", "Например: 10"), onDismiss = { showSetDialog = false }) { v ->
        val weight = v[0].replace(',', '.').toDoubleOrNull(); val reps = v[1].toIntOrNull()
        if(weight != null && weight >= 0 && reps != null && reps > 0) { val n = db.sets(activeExercise!!.id).size + 1; db.addSet(activeExercise!!.id, n, weight, reps); onRefresh(); showSetDialog = false }
        else Toast.makeText(context, "Введи вес и число повторений", Toast.LENGTH_SHORT).show()
    }
    confirm?.let { c -> ConfirmDialog(c.first, onConfirm = { c.second(); confirm = null; onRefresh() }, onDismiss = { confirm = null }) }
    showExerciseInfo?.let { ex -> ExerciseInfoDialog(ex, onDismiss = { showExerciseInfo = null }, onAddPhoto = { photoPicker.launch(arrayOf("image/*")) }) }
}

@Composable
private fun ExercisePicker(db: DiaryDb, onDismiss: () -> Unit, onCustom: () -> Unit, onChoose: (DiaryDb.Exercise) -> Unit) {
    var muscle by remember { mutableStateOf("Все") }
    val groups = listOf("Все", "Грудь", "Спина", "Плечи", "Бицепс", "Трицепс", "Ноги", "Пресс", "Кардио")
    val exercises = remember(muscle) { db.exercises(muscle) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Выбери упражнение") }, text = {
        Column(Modifier.heightIn(max = 500.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) { groups.take(4).forEach { FilterChip(selected = muscle==it, onClick = { muscle=it }, label = { Text(it, fontSize = 10.sp) }) } }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) { groups.drop(4).forEach { FilterChip(selected = muscle==it, onClick = { muscle=it }, label = { Text(it, fontSize = 10.sp) }) } }
            TextButton(onClick = onCustom) { Icon(Icons.Default.Add, null); Text("Создать своё упражнение") }
            LazyColumn { items(exercises) { ex -> ListItem(headlineContent = { Text(ex.name) }, supportingContent = { Text(ex.muscle) }, modifier = Modifier.clickable { onChoose(ex) }) } }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Закрыть") } })
}

@Composable
private fun ExerciseInfoDialog(ex: DiaryDb.Exercise, onDismiss: () -> Unit, onAddPhoto: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(ex.name) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(ex.muscle, color = mint, fontWeight = FontWeight.Bold)
            if (ex.photoUri != null) {
                val context = androidx.compose.ui.platform.LocalContext.current
                val bitmap = remember(ex.photoUri) { runCatching { context.contentResolver.openInputStream(Uri.parse(ex.photoUri))?.use { BitmapFactory.decodeStream(it) } }.getOrNull() }
                if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = ex.name, modifier = Modifier.fillMaxWidth().height(150.dp))
                else Text("Фото сохранено, но сейчас недоступно.", color = muted, fontSize = 12.sp)
            } else Box(Modifier.fillMaxWidth().height(110.dp).background(panel, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("Фото пока не добавлено", color = muted) }
            Text("Техника выполнения", fontWeight = FontWeight.SemiBold)
            Text(ex.instructions, fontSize = 14.sp)
            OutlinedButton(onClick = onAddPhoto, modifier = Modifier.fillMaxWidth()) { Text(if(ex.photoUri==null) "Добавить фото из галереи" else "Заменить фото") }
        }
    }, confirmButton = { TextButton(onClick = onDismiss) { Text("Готово") } })
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CustomExerciseDialog(onDismiss: () -> Unit, onSave: (String,String,String) -> Unit) {
    var name by remember { mutableStateOf("") }; var muscle by remember { mutableStateOf("Грудь") }; var instructions by remember { mutableStateOf("") }
    val groups = listOf("Грудь","Спина","Плечи","Бицепс","Трицепс","Ноги","Пресс","Кардио")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Своё упражнение") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(name,{name=it},label={Text("Название")},singleLine=true)
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=it}) { OutlinedTextField(value=muscle,onValueChange={},modifier=Modifier.menuAnchor(),readOnly=true,label={Text("Группа мышц")},trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)}); ExposedDropdownMenu(expanded,onDismissRequest={expanded=false}) { groups.forEach { DropdownMenuItem(text={Text(it)},onClick={muscle=it;expanded=false}) } } }
        OutlinedTextField(instructions,{instructions=it},label={Text("Инструкция по технике")},minLines=3)
    } }, confirmButton = { TextButton(onClick={if(name.isNotBlank()) onSave(name,muscle,instructions)}) { Text("Сохранить") } }, dismissButton = { TextButton(onClick=onDismiss) { Text("Отмена") } })
}

@Composable
private fun HealthScreen(db: DiaryDb, refresh: Int, onRefresh: () -> Unit) {
    val context = LocalContext.current
    var confirm by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    var pressureDialog by remember { mutableStateOf(false) }; var sleepDialog by remember { mutableStateOf(false) }
    val pressures = remember(refresh) { db.pressures() }; val sleeps = remember(refresh) { db.sleeps() }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Артериальное давление", fontSize=20.sp,fontWeight=FontWeight.Bold); Text("Верхнее · нижнее · пульс",color=muted,fontSize=12.sp) }; Button(onClick={pressureDialog=true}) { Icon(Icons.Default.Add,null); Text("Записать") } } }
        if(pressures.isEmpty()) item { EmptyState("Нет измерений", "Добавь первое измерение давления и пульса.") }
        items(pressures) { p -> CardBox { Row(verticalAlignment=Alignment.CenterVertically) { Text("${p.systolic}/${p.diastolic}",fontSize=24.sp,fontWeight=FontWeight.Bold); Text(" мм рт. ст.",color=muted,fontSize=12.sp); Spacer(Modifier.weight(1f)); Text("${p.pulse?.let { "$it уд/мин" } ?: "Пульс —"}",color=mint); IconButton(onClick={confirm=Pair("Удалить это измерение?",{db.deletePressure(p.id)})}) { Icon(Icons.Default.Delete,"Удалить измерение",tint=muted) } }; Text(dateTime(p.measuredAt),color=muted,fontSize=12.sp); if(p.note.isNotBlank()) Text(p.note,fontSize=13.sp) } }
        item { HorizontalDivider(color=Color(0xFF35404D), modifier=Modifier.padding(vertical=8.dp)) }
        item { Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Сон",fontSize=20.sp,fontWeight=FontWeight.Bold); Text("Время засыпания и пробуждения",color=muted,fontSize=12.sp) }; Button(onClick={sleepDialog=true}) { Icon(Icons.Default.Add,null); Text("Записать") } } }
        if(sleeps.isEmpty()) item { EmptyState("Нет записей сна", "Добавь время отхода ко сну и пробуждения.") }
        items(sleeps) { s -> CardBox { Row(verticalAlignment=Alignment.CenterVertically) { Text("${s.durationMin/60} ч ${s.durationMin%60} мин",fontSize=22.sp,fontWeight=FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("Качество ${s.quality}/5",color=mint); IconButton(onClick={confirm=Pair("Удалить запись сна?",{db.deleteSleep(s.id)})}) { Icon(Icons.Default.Delete,"Удалить запись сна",tint=muted) } }; Text("${date(s.sleepDate)} · ${s.bedtime} — ${s.wakeTime}",color=muted,fontSize=12.sp); if(s.note.isNotBlank()) Text(s.note,fontSize=13.sp) } }
        item { Text("Записи давления — это дневник наблюдений, а не диагноз. При тревожных симптомах обращайся за медицинской помощью.",color=muted,fontSize=12.sp) }
    }
    if(pressureDialog) InputDialog("Новое измерение давления",listOf("Верхнее, мм рт. ст.","Нижнее, мм рт. ст.","Пульс, уд/мин (необязательно)","Комментарий (необязательно)"),listOf("128","80","60",""),onDismiss={pressureDialog=false}) { v -> val s=v[0].toIntOrNull(); val d=v[1].toIntOrNull(); val p=v[2].toIntOrNull(); if(s!=null&&d!=null&&s in 50..300&&d in 30..200) { db.addPressure(s,d,p,v[3]);onRefresh();pressureDialog=false } else Toast.makeText(context,"Проверь значения давления",Toast.LENGTH_SHORT).show() }
    if(sleepDialog) SleepDialog(onDismiss={sleepDialog=false}) { bed,wake,mins,quality,note -> db.addSleep(System.currentTimeMillis(),bed,wake,mins,quality,note);onRefresh();sleepDialog=false }
    confirm?.let { c -> ConfirmDialog(c.first, onConfirm = { c.second(); confirm = null; onRefresh() }, onDismiss = { confirm = null }) }
}

@Composable
private fun SleepDialog(onDismiss: () -> Unit, onSave: (String,String,Int,Int,String) -> Unit) {
    var bed by remember { mutableStateOf("23:00") }; var wake by remember { mutableStateOf("07:00") }; var quality by remember { mutableIntStateOf(3) }; var note by remember { mutableStateOf("") }
    val mins = remember(bed,wake) { runCatching { val a=bed.split(":").map{it.toInt()}; val b=wake.split(":").map{it.toInt()}; require(a.size==2&&b.size==2&&a[0] in 0..23&&b[0] in 0..23&&a[1] in 0..59&&b[1] in 0..59); ((b[0]*60+b[1]-(a[0]*60+a[1])+1440)%1440) }.getOrDefault(0) }
    AlertDialog(onDismissRequest=onDismiss,title={Text("Запись сна")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(bed,{bed=it},label={Text("Лёг спать (ЧЧ:ММ)")},singleLine=true)
        OutlinedTextField(wake,{wake=it},label={Text("Проснулся (ЧЧ:ММ)")},singleLine=true)
        Text("Продолжительность: ${mins/60} ч ${mins%60} мин",color=mint,fontWeight=FontWeight.SemiBold)
        Text("Качество сна: $quality из 5")
        Slider(value=quality.toFloat(),onValueChange={quality=it.toInt().coerceIn(1,5)},valueRange=1f..5f,steps=3)
        OutlinedTextField(note,{note=it},label={Text("Комментарий")})
    }},confirmButton={TextButton(onClick={if(mins>0) onSave(bed,wake,mins,quality,note)}){Text("Сохранить")}},dismissButton={TextButton(onClick=onDismiss){Text("Отмена")}})
}

@Composable
private fun BodyScreen(db: DiaryDb, refresh: Int, onRefresh: () -> Unit) {
    var confirm by remember { mutableStateOf<Pair<String, () -> Unit>?>(null) }
    var dialog by remember { mutableStateOf(false) }; val rows=remember(refresh){db.measurements()}; val latest=rows.firstOrNull()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Замеры тела",fontSize=21.sp,fontWeight=FontWeight.Bold); Text("Отслеживай изменения формы",color=muted,fontSize=12.sp) }; Button(onClick={dialog=true}) { Icon(Icons.Default.Add,null);Text("Добавить") } }
        Spacer(Modifier.height(12.dp))
        CardBox { Text("Последние показатели",color=mint,fontWeight=FontWeight.Bold); listOf("Вес" to latest?.weight,"Талия" to latest?.waist,"Грудь" to latest?.chest,"Плечи" to latest?.shoulders,"Рука" to latest?.arm,"Бедро" to latest?.thigh).forEach { (label,value) -> Row(Modifier.fillMaxWidth().padding(vertical=4.dp),horizontalArrangement=Arrangement.SpaceBetween) { Text(label,color=muted); Text(value?.let{fmt(it)} ?: "—",fontWeight=FontWeight.SemiBold) } } }
        Spacer(Modifier.height(10.dp)); Text("История замеров",fontWeight=FontWeight.Bold,fontSize=17.sp)
        if(rows.isEmpty()) EmptyState("Пока нет замеров", "Добавь вес и окружности тела.")
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) { items(rows) { r -> CardBox { Row(verticalAlignment=Alignment.CenterVertically) { Text(date(r.measuredAt),fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f)); IconButton(onClick={confirm=Pair("Удалить замеры от ${date(r.measuredAt)}?",{db.deleteMeasurement(r.id)})}) { Icon(Icons.Default.Delete,"Удалить замеры",tint=muted) } }; Text("Вес ${r.weight?.let{fmt(it)+" кг"}?:"—"} · Талия ${r.waist?.let{fmt(it)+" см"}?:"—"}",color=muted,fontSize=13.sp); Text("Грудь ${r.chest?.let{fmt(it)}?:"—"} · Плечи ${r.shoulders?.let{fmt(it)}?:"—"} · Рука ${r.arm?.let{fmt(it)}?:"—"} · Бедро ${r.thigh?.let{fmt(it)}?:"—"}",color=muted,fontSize=12.sp) } } }
    }
    if(dialog) InputDialog("Новые замеры",listOf("Вес, кг","Талия, см","Грудь, см","Плечи, см","Рука, см","Бедро, см"),listOf("108","113","","","", ""),onDismiss={dialog=false}) { v ->
        fun parse(i:Int)=v[i].replace(',','.').toDoubleOrNull()
        if(v.any{it.isNotBlank()}) { db.addMeasurement(parse(0),parse(1),parse(2),parse(3),parse(4),parse(5));onRefresh() };dialog=false
    }
    confirm?.let { c -> ConfirmDialog(c.first, onConfirm = { c.second(); confirm = null; onRefresh() }, onDismiss = { confirm = null }) }
}

@Composable
private fun AnalyticsScreen(db: DiaryDb, refresh: Int) {
    val m=remember(refresh){db.measurements().reversed()}; val p=remember(refresh){db.pressures().reversed()}; val s=remember(refresh){db.sleeps().reversed()}
    LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item { Text("Аналитика",fontSize=22.sp,fontWeight=FontWeight.Bold);Text("История показателей по твоим записям",color=muted,fontSize=12.sp) }
        item { CardBox { Text("Динамика веса",fontWeight=FontWeight.SemiBold); if(m.count{it.weight!=null}<2) Text("Добавь минимум два замера веса для графика.",color=muted,fontSize=12.sp) else { SimpleLineChart(m.mapNotNull{it.weight}); Text("Последний вес: ${m.lastOrNull()?.weight?.let{fmt(it)+" кг"}?:"—"}",color=mint) } } }
        item { CardBox { Text("Динамика талии",fontWeight=FontWeight.SemiBold); if(m.count{it.waist!=null}<2) Text("Добавь минимум два замера талии для графика.",color=muted,fontSize=12.sp) else SimpleLineChart(m.mapNotNull{it.waist}) } }
        item { CardBox { Text("Давление",fontWeight=FontWeight.SemiBold); if(p.isEmpty()) Text("Пока нет измерений.",color=muted) else { Text("Последнее: ${p.last().systolic}/${p.last().diastolic} мм рт. ст.",color=mint); Text("Записей: ${p.size}",color=muted,fontSize=12.sp) } } }
        item { CardBox { Text("Сон",fontWeight=FontWeight.SemiBold); if(s.isEmpty()) Text("Пока нет записей сна.",color=muted) else { val avg=s.map{it.durationMin}.average().toInt(); Text("Средняя продолжительность: ${avg/60} ч ${avg%60} мин",color=mint); Text("Записей: ${s.size}",color=muted,fontSize=12.sp) } } }
        item { Text("Графики строятся по сохранённым записям. При отсутствии данных они не показывают прогнозы.",color=muted,fontSize=12.sp) }
    }
}

@Composable
private fun SimpleLineChart(values: List<Double>) {
    Canvas(Modifier.fillMaxWidth().height(130.dp).padding(vertical=8.dp)) {
        if(values.size<2) return@Canvas
        val min=values.minOrNull()!!; val max=values.maxOrNull()!!; val range=(max-min).takeIf{it>0.001}?:1.0
        val path=Path()
        values.forEachIndexed { i,v -> val x=size.width*i/(values.size-1); val y=size.height-( ((v-min)/range).toFloat()*size.height*0.78f+size.height*0.1f ); if(i==0) path.moveTo(x,y) else path.lineTo(x,y) }
        drawLine(Color(0xFF3B4654), androidx.compose.ui.geometry.Offset(0f,size.height*0.9f), androidx.compose.ui.geometry.Offset(size.width,size.height*0.9f),strokeWidth=1.dp.toPx())
        drawPath(path,mint,style=androidx.compose.ui.graphics.drawscope.Stroke(width=3.dp.toPx()))
    }
}

@Composable
private fun InputDialog(title: String, labels: List<String>, placeholders: List<String>, onDismiss: () -> Unit, onSave: (List<String>) -> Unit) {
    val values = remember(title) { mutableStateListOf<String>().apply { repeat(labels.size) { add("") } } }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
            labels.forEachIndexed { i, label ->
                val numeric = label.contains("кг") || label.contains("см") || label.contains("мм рт") || label.contains("уд") || label.contains("Повтор")
                OutlinedTextField(value = values[i], onValueChange = { values[i] = it }, label = { Text(label, fontSize = 12.sp) }, placeholder = { Text(placeholders.getOrElse(i) { "" }, color = muted) }, singleLine = labels.size == 1 || i != labels.lastIndex, keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text), modifier = Modifier.fillMaxWidth())
            }
        }
    }, confirmButton = { TextButton(onClick = { onSave(values.toList()) }) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
}

@Composable
private fun ConfirmDialog(text: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Подтверди удаление") }, text = { Text(text) }, confirmButton = { TextButton(onClick = onConfirm) { Text("Удалить", color = Color(0xFFFF8A80)) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } })
}

@Composable
private fun CardBox(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier=modifier,shape=RoundedCornerShape(18.dp),colors=CardDefaults.cardColors(containerColor=panel)) { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp),content=content) }
}
@Composable private fun StatCard(title:String,value:String,caption:String,modifier:Modifier=Modifier) { CardBox(modifier) { Text(title,color=muted,fontSize=11.sp);Text(value,fontSize=19.sp,fontWeight=FontWeight.Bold);Text(caption,color=muted,fontSize=10.sp) } }
@Composable private fun SectionTitle(text:String) { Text(text,fontSize=17.sp,fontWeight=FontWeight.Bold) }
@Composable private fun QuickCard(text:String,icon: androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier=Modifier,onClick:()->Unit) { CardBox(modifier.clickable(onClick=onClick)) { Icon(icon,null,tint=mint);Text(text,fontWeight=FontWeight.SemiBold,fontSize=13.sp) } }
@Composable private fun EmptyState(title:String,description:String) { Column(Modifier.fillMaxWidth().padding(vertical=28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(6.dp)) { Text(title,fontWeight=FontWeight.SemiBold);Text(description,color=muted,fontSize=12.sp) } }
private fun fmt(v:Double)=String.format(Locale.getDefault(),"%.1f",v)
private fun date(t:Long)=SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(Date(t))
private fun dateTime(t:Long)=SimpleDateFormat("dd.MM.yyyy · HH:mm",Locale.getDefault()).format(Date(t))
